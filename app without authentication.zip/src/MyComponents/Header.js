import React, { useState } from 'react'
import {FaCartPlus} from 'react-icons/fa'
import { Link } from 'react-router-dom'
import SearchResult from './SearchResult';

export default function Header({ cartCount }) {
  const [input, setInput] = useState("");
  const [results, setResults] = useState([]);

  const fetchData = (value) => {
    fetch("https://fakestoreapi.com/products")
      .then((response) => response.json())
      .then((json) => {
        const filteredResults = json.filter((product) =>
          value && product && product.title && product.title.toLowerCase().includes(value.toLowerCase())
        );
        setResults(filteredResults);
      })
      .catch((error) => {
        console.error('Error fetching product data:', error);
      });
  };
  

  const handleChange = (value) => {
    setInput(value);
    fetchData(value);
  };

  const [isSearchBoxVisible, setSearchBoxVisible] = useState(true);

  const showSearchBox = () => {
    setSearchBoxVisible(true);
  };
  
 

  return (
    <div className='header'>

<nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">B4U</Link>
        {/* <Link className="navbar-brand" to="/">{props.title}</Link> */}
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <Link className="nav-link active" aria-current="page" to="/">Home</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link active" aria-current="page" to="/about">About</Link>
            </li>
            
            <li className="nav-item dropdown">
              <Link className="nav-link dropdown-toggle" to="/" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                category
              </Link>
              <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><Link className="dropdown-item" to="/Electronics">Electronics</Link></li>
                <li><Link className="dropdown-item" to="/Clothes">Clothes</Link></li>
                <li><hr className="dropdown-divider" /></li>
                <li><a className="dropdown-item" href="/">Something else here</a></li>
              </ul>
            </li>
          </ul>
          <form className="d-flex">
            <input className="form-control me-2" type="search" onClick={showSearchBox} placeholder="Search" value={input} onChange={(e) => handleChange(e.target.value)} aria-label="Search" />
          <SearchResult results={results} isSearchBoxVisible={isSearchBoxVisible} setSearchBoxVisible={setSearchBoxVisible}/>
            <button className="btn btn-outline-success" type="submit">Search</button>
          </form>
          <Link to="/cartList" className='HeaderCartImg'><FaCartPlus fontSize="25px" />
                  <sup className='cartCount'>{cartCount}</sup>
          </Link>
          
        </div>
      </div>
    </nav>
    </div>
  )
}
